<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">


<title>
  
    Frontrunner
  
</title>

<!-- Bootstrap core CSS -->
<link href="style/bootstrap.css" rel="stylesheet">

<!-- Documentation extras -->
<link href="style/docs.css" rel="stylesheet">
<link href="style//pygments-manni.css" rel="stylesheet">

<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script src="./assets/js/html5shiv.js"></script>
  <script src="./assets/js/respond.min.js"></script>
<![endif]-->

<!-- Favicons -->
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="./assets/ico/apple-touch-icon-144-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="./assets/ico/apple-touch-icon-114-precomposed.png">
  <link rel="apple-touch-icon-precomposed" sizes="72x72" href="./assets/ico/apple-touch-icon-72-precomposed.png">
                <link rel="apple-touch-icon-precomposed" href="./assets/ico/apple-touch-icon-57-precomposed.png">
                               <link rel="shortcut icon" href="./assets/ico/favicon.png">

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="style/bootstrap.min.js"></script>
<script>document.cookie='resolution='+Math.max(screen.width,screen.height)+'; path=/';</script>
    <!-- Le Scroll Function-->
  
<script type="text/javascript">

$("document").ready(function() {			
				
$('.scroll').click(function(e){
      
    // Stop the HTML page jump executing. 

    e.preventDefault();
       
    // Create the class we will jump to from the link text

    var myclass = '.'+$(this).text();
       
    // Animate is used to scroll to our new position.

    $('html, body').animate({
        
        //Set the position to scroll to by finding the div's top offset

        scrollTop: $(myclass).offset().top

    }, 2000);
        
});
});
</script>	
<style>
img.resize{
    width:59%; /* you can use % */
    height: auto;
}
</style>	
</head>
  
<body class="bs-docs-home">

    <!-- Docs master nav -->
    <div class="navbar navbar-inverse navbar-fixed-top bs-docs-nav">
  <div class="container">
    <button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".bs-navbar-collapse">
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
    <a href="#top" class="scroll navbar-brand">Frontrunner</a>
    <div class="nav-collapse collapse bs-navbar-collapse">
      <ul class="nav navbar-nav">
        <li>
          <a href="#iphone" class="scroll" >Looks</a>
        </li>
        <li>
          <a href="javascript:;">iPhone</a>
        </li>
        <li>
          <a href="javascript:;">Development</a>
        </li>
        <li>
          <a href="#contact" class="scroll">Contact</a>
        </li>
      </ul>
    </div>
  </div>
</div>


    <!-- Page content of course! -->
<a name="top"></a> 
<div class="Top Frontrunner bs-masthead"> 
<div class="container">
    <h1>Frontrunner </h1>
    <p class="lead">A powerful, intuitive new application that will help you pick the right spots to go to.</p>
    <p><strong>Coming Soon!</strong> Beta version expected in early September!</p>
 </div> 
<div class="Looks">
 <a name="iphone"> </a>    
<img src="pictures/Frontrunnerlook_smaller.png" alt="Front Runner Look">
</div>

</div> <!--Bs-masthead-->
</div><!--container-->

<br><br>
<div class="container">
<div class="Contact">
<a name="contact"></a>

<hr class="featurette-divider">

<div class="featurette">

<h2 class="featurette-heading">Get in touch with us </h2>
<p class="lead">Let us know what you think, what you want the app to have, or anything else.</p>

<form>
<div class="row">
<div class="col col-lg-4 form-group">
      <label for="InputName">Name</label>
      <input type="text" class="form-control" id="InputeName" placeholder="Enter Name">
    </div>

<div class="col col-lg-4 form-group">
      <label for="InputEmail">Email address</label>
      <input type="text" class="form-control" id="InputEmail" placeholder="Enter email">
    </div>
</div><!---Row-->

<div class="form-group">
  <label for="Message">Message</label>
<textarea class="form-control" rows="3"id="Message"  placeholder="Message"></textarea>
</div>
<p class="pull-right"><button type="button" class="btn btn-success">Submit</button></p>
</form>
<br><br>
	</div>   <!--featurette-->
</div> <!--CONTACT-->
<hr class="featurette-divider">
</div> <!--Container-->

<br><br><br><br><br><br>
<!-- FOOTER -->
<footer>
<p class="pull-right"><a href="#top" class="scroll">Top</a></p>
<p>Project by Nick, Dan and Luciano</p>

<div class="bs-social">
  <ul class="bs-social-buttons">
    <li class="follow-btn">
      <a href="https://twitter.com/frontrunner" class="twitter-follow-button" data-link-color="#0069D6" data-show-count="true">Follow @Frontrunner</a>
    </li>
    <li class="tweet-btn">
      <a href="https://twitter.com/share" class="twitter-share-button" data-url="http://frontrunner.webege.com" data-count="horizontal" data-via="twbootstrap" data-related="mdo:FrontRunner App">Tweet</a>
    </li>
  </ul>
</div>
</footer>
</div><!-- /.container -->


 </body>  

 <!-- JS and analytics only. -->
    <!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="./assets/js/jquery.js"></script>
<script src="./dist/js/bootstrap.js"></script>

<script src="http://platform.twitter.com/widgets.js"></script>
<script src="./assets/js/holder.js"></script>

<script src="./assets/js/application.js"></script>

</html>		


									